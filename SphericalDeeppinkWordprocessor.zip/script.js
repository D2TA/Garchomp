function onClickName1(){
  document.getElementById('NameChangeOut').style.display = 'inline';
  document.getElementById('NameChangeIn' ).style.display = 'none';
}

function onClickName2(){
  document.getElementById('NameChangeOut').style.display = 'none';
  document.getElementById('NameChangeIn' ).style.display = 'inline';  
}